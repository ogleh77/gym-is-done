CREATE TRIGGER phone_updated_trigger
    AFTER UPDATE ON customers
    WHEN old.phone <> new.phone

BEGIN
   UPDATE payments SET customer_phone_fk=new.phone WHERE customer_phone_fk=old.phone;
    
END;

